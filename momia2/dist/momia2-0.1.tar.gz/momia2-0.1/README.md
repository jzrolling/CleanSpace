# momia2 development version
### This version is currently being slowly updated, will resume routine maintenance/development in late March.
To install the most up-to-date development version, run:
```
pip install git+https://github.com/jzrolling/momia2.git

```
