__author__ = 'jz-rolling'
__version__ = '0.2.1' # revised docstrings using cursor + GPT4


from .generic import *
from .linalg import *

"""
============================= Description =============================
contour manipulation
"""

def find_contour_marching_squares(binary_mask,
                                  image = None,
                                  level=0.1,
                                  dilation=False,
                                  erosion=True,
                                  dark_background=False,
                                  gaussian_smooth_sigma=1):
    """
    finds the outermost contour of a binary mask using the marching-squares algorithm.
    :param binary_mask: binary mask of the object
    :param image: optional bright-field image to use as reference
    :param level: threshold level for contour detection
    :param dilation: boolean flag to perform binary dilation on the mask
    :param erosion: boolean flag to perform binary erosion on the mask
    :param dark_background: boolean flag to indicate if the image has a dark background
    :param gaussian_smooth_sigma: sigma value for Gaussian smoothing of the image
    :return: outermost contour of the object
    """
    from skimage import morphology, filters, measure

    binary_mask = binary_mask.astype(int)
    if erosion:
        binary_mask = morphology.binary_erosion(binary_mask).astype(int)
    if dilation:
        binary_mask = morphology.binary_dilation(binary_mask).copy()

    # use the bright-field image as reference if available:
    if image is not None:
        if not identical_shapes([image, binary_mask]):
            raise ValueError('Input images are of different sizes!')
        if not dark_background:
            image = filters.gaussian(invert_normalize(image),sigma=gaussian_smooth_sigma)
        else:
            image = filters.gaussian(image,sigma=gaussian_smooth_sigma)
        intensity_mask = binary_mask*image
    else:
        intensity_mask = binary_mask
    contour = measure.find_contours(intensity_mask, level=level)[0]
    return contour


def simplify_polygon(polygon,
                     tolerance=0.95,
                      interp_distance=1,
                      min_segment_count=2):
    """
    Simplifies a given polygon using the Ramer-Douglas-Peucker algorithm and linear interpolation.

    :param polygon: A 2D numpy array of shape (n, 2) representing the polygon.
    :param tolerance: A float representing the maximum distance for a point to be considered as a candidate for reduction, default value is 0.95.
    :param interp_distance: A float representing the distance between interpolated points, default value is 1.
    :param min_segment_count: An integer representing the minimum number of interpolation points, default value is 2.
    :return: A 2D numpy array of the simplified and interpolated polygon.
    """
    from skimage.measure import approximate_polygon
    approximation = approximate_polygon(polygon,tolerance=tolerance)
    linear_interpolated_segments=[]
    for i in range(len(approximation)-1):
        p1 = approximation[i]
        p2 = approximation[i+1]
        dist = distance(p1,p2)
        steps = max(int(round(dist/interp_distance)),min_segment_count)
        linear_interpolated_segments.append(np.array([np.linspace(p1[0],p2[0],steps),np.linspace(p1[1],p2[1],steps)]).T[:-1])
    linear_interpolated_segments.append(np.array([approximation[-1]]))
    return np.concatenate(linear_interpolated_segments)


@jit(nopython=True, cache=True)
def estimate_outline_length(closed_coords):
    max_L = 0
    for i in range(len(closed_coords)):
        for j in range(i+1,len(closed_coords)):
            x1,y1 = closed_coords[i]
            x2,y2 = closed_coords[j]
            dist =  np.sqrt((x2-x1)**2+(y2-y1)**2)
            if dist > max_L:
                max_L = dist
    return max_L
